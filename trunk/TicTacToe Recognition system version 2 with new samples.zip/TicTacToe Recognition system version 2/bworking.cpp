//#include "/usr/local/include/opencv/highgui.h"

#include "highgui.h"
#include <string.h>
#include <iostream>
#include<algorithm>
#include<fstream>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include "cv.h"


using namespace std;
using namespace cv;


char board[10]="";
int thresh = 50;
CvMemStorage* storage = 0;


class boarddetect
{

private:
    int a1,a2,b1,b2;
//const char* wndname = "Square Detection Demo";

// helper function:
// finds a cosine of angle between vectors
// from pt0->pt1 and from pt0->pt2
double angle( CvPoint* pt1, CvPoint* pt2, CvPoint* pt0 )
{
    double dx1 = pt1->x - pt0->x;
    double dy1 = pt1->y - pt0->y;
    double dx2 = pt2->x - pt0->x;
    double dy2 = pt2->y - pt0->y;
    return (dx1*dx2 + dy1*dy2)/sqrt((dx1*dx1 + dy1*dy1)*(dx2*dx2 + dy2*dy2) + 1e-10);
}

// returns sequence of squares detected on the image.
// the sequence is stored in the specified memory storage

IplImage* crop(IplImage* img,int x,int y,int w,int h)
{//IplImage* img3) {
   cvSetImageROI(img,cvRect(x,y,w,h));
   IplImage* img2=cvCreateImage(cvGetSize(img),img->depth,img->nChannels);
   cvCopy(img,img2,NULL);
   cvSetImageROI(img,cvRect(0,0,img->width,img->height));
   //cvSaveImage( "cropped.jpg" , img2);
   return img2;
}


IplImage* rotate(IplImage* img,double angle) {

    IplImage* img1= cvCloneImage(img);;
    CvPoint2D32f center = cvPoint2D32f( img->width/2, img->height/2 );
    CvMat* warp_mat = cvCreateMat(2,3,CV_32FC1);
    cv2DRotationMatrix( center, angle, 1, warp_mat);
    cvWarpAffine( img, img1, warp_mat );
    return img1;

}


CvSeq* findSquares4( IplImage* img, CvMemStorage* storage )
{
    CvSeq* contours;
    int i, c, l, N = 11;
    CvSize sz = cvSize( img->width & -2, img->height & -2 );
    IplImage* timg = cvCloneImage( img ); // make a copy of input image
    IplImage* gray = cvCreateImage( sz, 8, 1 );
    IplImage* pyr = cvCreateImage( cvSize(sz.width/2, sz.height/2), 8, 3 );
    IplImage* tgray;
    CvSeq* result;
    double s, t;
    // create empty sequence that will contain points -
    // 4 points per square (the square's vertices)
    CvSeq* squares = cvCreateSeq( 0, sizeof(CvSeq), sizeof(CvPoint), storage );

    // select the maximum ROI in the image
    // with the width and height divisible by 2
    cvSetImageROI( timg, cvRect( 0, 0, sz.width, sz.height ));

    //IplImage* img = cvLoadImage( "exam.jpg");
    //cvSaveImage( "cropped.jpg" , crop(img,0,0,sz.width, sz.height));

    // down-scale and upscale the image to filter out the noise
    cvPyrDown( timg, pyr, 7 );
    cvPyrUp( pyr, timg, 7 );
    tgray = cvCreateImage( sz, 8, 1 );

    // find squares in every color plane of the image
    for( c = 0; c < 3; c++ )
    {
        // extract the c-th color plane
        cvSetImageCOI( timg, c+1 );
        cvCopy( timg, tgray, 0 );

        // try several threshold levels
        for( l = 0; l < N; l++ )
        {
            // hack: use Canny instead of zero threshold level.
            // Canny helps to catch squares with gradient shading
            if( l == 0 )
            {
                // apply Canny. Take the upper threshold from slider
                // and set the lower to 0 (which forces edges merging)
                cvCanny( tgray, gray, 0, thresh, 5 );
                // dilate canny output to remove potential
                // holes between edge segments
                cvDilate( gray, gray, 0, 1 );
            }
            else
            {
                // apply threshold if l!=0:
                //     tgray(x,y) = gray(x,y) < (l+1)*255/N ? 255 : 0
                cvThreshold( tgray, gray, (l+1)*255/N, 255, CV_THRESH_BINARY );
            }

            // find contours and store them all as a list
            cvFindContours( gray, storage, &contours, sizeof(CvContour),
                CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE, cvPoint(0,0) );

            // test each contour
            while( contours )
            {
                // approximate contour with accuracy proportional
                // to the contour perimeter
                result = cvApproxPoly( contours, sizeof(CvContour), storage,
                    CV_POLY_APPROX_DP, cvContourPerimeter(contours)*0.02, 0 );
                // square contours should have 4 vertices after approximation
                // relatively large area (to filter out noisy contours)
                // and be convex.
                // Note: absolute value of an area is used because
                // area may be positive or negative - in accordance with the
                // contour orientation
                if( result->total == 4 &&
                    cvContourArea(result,CV_WHOLE_SEQ,0) > 1000 &&
                    cvCheckContourConvexity(result) )
                {
                    s = 0;

                    for( i = 0; i < 5; i++ )
                    {
                        // find minimum angle between joint
                        // edges (maximum of cosine)
                        if( i >= 2 )
                        {
                            t = fabs(angle(
                            (CvPoint*)cvGetSeqElem( result, i ),
                            (CvPoint*)cvGetSeqElem( result, i-2 ),
                            (CvPoint*)cvGetSeqElem( result, i-1 )));
                            s = s > t ? s : t;
                        }
                    }

                    // if cosines of all angles are small
                    // (all angles are ~90 degree) then write quandrange
                    // vertices to resultant sequence
                    if( s < 0.3 )
                        for( i = 0; i < 4; i++ )
                            cvSeqPush( squares,
                                (CvPoint*)cvGetSeqElem( result, i ));
                }

                // take the next contour
                contours = contours->h_next;
            }
        }
    }

    // release all the temporary images
    cvReleaseImage( &gray );
    cvReleaseImage( &pyr );
    cvReleaseImage( &tgray );
    cvReleaseImage( &timg );

    return squares;
}



int min(int a,int b,int c,int d)
{
    //cout<<" "<<a<<" "<<b<<" "<<c<<" "<<d<<"insidemin\n";
    if((a<=b)&&(a<=c)&&(a<=d))
    {
        return a;
    }

    else if((b<=a)&&(b<=c)&&(b<=d))
    {
        return b;
    }
    else if((c<=b)&&(c<=a)&&(c<=d))
    {
        return c;
    }
    else
    {
        return d;
    }
}

int max(int a,int b,int c,int d)
{
    //cout<<" "<<a<<" "<<b<<" "<<c<<" "<<d<<"insidemax\n";

    if((a>=b)&&(a>=c)&&(a>=d))
    {
//        cout<<"bumb";
        return a;
    }
    else if((b>=a)&&(b>=c)&&(b>=d))
    {
        return b;
    }
    else if((c>=b)&&(c>=a)&&(c>=d))
    {
        return c;
    }
    else
    {
        return d;
    }
}

// the function draws all the squares in the image

IplImage* cutsq( IplImage* img, CvSeq* squares,IplImage* src )
{
    CvSeqReader reader;
    IplImage* cpy = cvCloneImage( img );
    int i;

    // initialize reader of the sequence
    cvStartReadSeq( squares, &reader, 0 );

    // read 4 sequence elements at a time (all vertices of a square)
    for( i = 0; i < squares->total; i += 4 )
    {
        CvPoint pt[4], *rect = pt;
        int count = 4;

        // read 4 vertices
        CV_READ_SEQ_ELEM( pt[0], reader );
        CV_READ_SEQ_ELEM( pt[1], reader );
        CV_READ_SEQ_ELEM( pt[2], reader );
        CV_READ_SEQ_ELEM( pt[3], reader );

        // draw the square as a closed polyline
       // cvPolyLine( cpy, &rect, &count, 1, 1, CV_RGB(0,255,0), 3, CV_AA, 0 );

        IplImage* img2 = cvCloneImage( src );//cvLoadImage( "cropped.jpg");


        int x1=min(pt[0].x,pt[1].x,pt[2].x,pt[3].x);
        int y1=min(pt[0].y,pt[1].y,pt[2].y,pt[3].y);
        int x2=max(pt[0].x,pt[1].x,pt[2].x,pt[3].x);
        int y2=max(pt[0].y,pt[1].y,pt[2].y,pt[3].y);


        //cout<<" "<<x1<<" "<<y1<<" "<<x2<<" "<<y2<<"-------";
        //cout<<" "<<y2<<endl;
        cvSetImageROI( img2, cvRect( x1,y1,x2-x1,y2-y1));//pt[1].x,pt[1].y,pt[3].x-pt[1].x,pt[3].y-pt[1].y));

        //cvSetImageROI( img2, cvRect( pt[1].x,pt[1].y,pt[3].x-pt[1].x,pt[3].y-pt[1].y));

        //cvSetImageROI( img2, cvRect( pt[1].x-30,pt[0].y-30,pt[3].x-pt[1].x+30,pt[2].y-pt[0].y+30));
        cout<<"-"<<pt[1].x<<"-"<<pt[0].y<<" -"<<pt[3].x-pt[1].x<<" -"<<pt[2].y-pt[0].y;
        //char nm[15];
        //sprintf(nm,"square%d.png",i);
        if(i==0)//(squares->total)-8)
        {
        return img2;
        //cvSaveImage( "cutsees.png" , img2);//crop(img2,0,0,pt[0], pt[1]));
        break;
        }
        cvReleaseImage(&img2);

    }

    // show the resultant image
    //cvShowImage( wndname, cpy );
    cvReleaseImage( &cpy );
}




IplImage* rotatesq( IplImage* img, CvSeq* squares,IplImage* src )
{

    CvSeqReader reader;
    IplImage* cpy = cvCloneImage( img );
    int i;

    // initialize reader of the sequence
    cvStartReadSeq( squares, &reader, 0 );

    // read 4 sequence elements at a time (all vertices of a square)
    for( i = 0; i < squares->total; i += 4 )
    {
        CvPoint pt[4], *rect = pt;
        int count = 4;

        // read 4 vertices
        CV_READ_SEQ_ELEM( pt[0], reader );
        CV_READ_SEQ_ELEM( pt[1], reader );
        CV_READ_SEQ_ELEM( pt[2], reader );
        CV_READ_SEQ_ELEM( pt[3], reader );

        // draw the square as a closed polyline
       // cvPolyLine( cpy, &rect, &count, 1, 1, CV_RGB(0,255,0), 3, CV_AA, 0 );

        IplImage* img2 = cvCloneImage( src );//cvLoadImage( "cropped.jpg");

        //cvSetImageROI( img2, cvRect( pt[1].x-30,pt[0].y-30,pt[3].x-pt[1].x+30,pt[2].y-pt[0].y+30));
        //char nm[15];
        //sprintf(nm,"square%d.png",i);
        if(i==0)//(squares->total)-8)
        {

            int x1=min(pt[0].x,pt[1].x,pt[2].x,pt[3].x);
            int y1=min(pt[0].y,pt[1].y,pt[2].y,pt[3].y);
            int x2=max(pt[0].x,pt[1].x,pt[2].x,pt[3].x);
            int y2=max(pt[0].y,pt[1].y,pt[2].y,pt[3].y);

            a1=pt[1].x;
            a2=pt[1].y;
            b1=pt[1].x;
            b2=pt[1].y;


            //cout<<"  "<<atan((pt[2].y-pt[1].y)/(pt[2].x-pt[1].x))*180/3.141592<<"en\n";
            //cout<<"  "<<(pt[2].y-pt[1].y)/(pt[2].x-pt[1].x)<<"en\n";
            //cout<<(double)91/326<<"--dsfg--";
            //cout<<"  "<<(pt[2].y-pt[1].y)<<"\n"<<(pt[2].x-pt[1].x)<<"en\n";


            //cout<<x1<<"  "<<y1<<"  "<<x2<<"  "<<y2<<"  "<<endl;
            //cout<<pt[2].x-pt[1].x<<endl;
            //cout<<pt[2].y-pt[1].y<<endl;

            //cout<<"--asdfasdf----"<<atan((double)(pt[2].y-pt[1].y)/(pt[2].x-pt[1].x))*180/3.141592;
            img2 = cvCloneImage(rotate(img2,atan((double)(pt[2].y-pt[1].y)/(pt[2].x-pt[1].x))*180/3.141592));

        //cvSaveImage( nm , img2);//crop(img2,0,0,pt[0], pt[1]));
        return img2;

        //break;
        }
        cvReleaseImage(&img2);

    }

    return cpy;
}


public:



IplImage* cut(IplImage* img)
{
    int i=0, c;
    storage = cvCreateMemStorage(0);
    img = cvCloneImage( cutsq( img, findSquares4( img, storage ),img ));
    return img;
}




IplImage* rot(IplImage* img)
{
    int i=0, c;
    storage = cvCreateMemStorage(0);
    img= cvCloneImage(rotatesq( img, findSquares4( img, storage ),img ));
    return img;
}

};


class imageProcess
{
    private:

    public:

int breakimages()
{
    unsigned int width;unsigned int height;
    //IplImage* img = cvLoadImage( "sample.jpg");
    IplImage* img = cvLoadImage( "cut.png");
    //img=crop(img);
    //test(img);

    width=img->width;
    height=img->height;


    char t[6];
    unsigned int unitX=floor(width/3),unitY=floor(height/3);

    //cvSaveImage( "image.tif" , img);

    int i=0,j=0;
    for(int i=0;i<3;++i)
    {
        for(int j=0;j<3;++j)
        {
            cvSetImageROI(img,cvRect(unitX*j,unitY*i,unitX,unitY));
            IplImage* img11=cvCreateImage(cvGetSize(img),img->depth,img->nChannels);
            cvCopy(img,img11,NULL);
            cvSetImageROI(img,cvRect(0,0,width,height));
            sprintf(t,"%d%d.tif",i+1,j+1);
            cvSaveImage( t , img11);
        }
    }

    IplImage* img33=cvCreateImage(cvGetSize(img),img->depth,img->nChannels);

    cvReleaseImage( &img );

    return 0;
}


int convert2text()
{
    char t[20];
    for(int i=0;i<3;++i)
    {
        for(int j=0;j<3;++j)
        {
             sprintf(t,"tesseract %d%d.tif %d%d",i+1,j+1,i+1,j+1);
             system(t);
        }
    }


	return 0;
}

int getboard()
{
string s;
fstream fio;
char t[20];
int x=1;
for(int i=0;i<3;++i)
    {
        for(int j=0;j<3;++j)
        {
             sprintf(t,"%d%d.txt",i+1,j+1);
             fio.open(t);
             getline(fio,s);

            transform(s.begin(), s.end(), s.begin(),(int (*)(int))toupper);

             cout<<s<<" ";
             //cout<<s.find("><")<<endl;

            if((s.find("X")<=10)||(s.find("><")<=10)||(s.find("K")<=10))
                board[x]='X';
            else if((s.find("0")<=10)||(s.find("O")<=10)||(s.find("Q")<=10)||(s.find("6")<=10)||(s.find("9")<=10))
                board[x]='O';
            else
            {
                    //the Cross or Golla can be in the next line
                    getline(fio,s);
                    if((s.find("X")<=10)||(s.find("><")<=10)||(s.find("K")<=10))
                            board[x]='X';
                    else if((s.find("0")<=10)||(s.find("O")<=10)||(s.find("Q")<=10)||(s.find("6")<=10)||(s.find("9")<=10))
                        board[x]='O';
                    else
                        board[x]=' ';
                }

            fio.close();


            sprintf(t,"rm %d%d.tif",i+1,j+1);system(t);sprintf(t,"rm %d%d.txt",i+1,j+1);system(t);

            x++;
        }
        cout<<endl;
    }

//system("rm image.tif");
return 0;
}


};

int m1()
{

return 0;
}


int main()
{
    boarddetect b;
    imageProcess ip;

    IplImage* i = cvLoadImage( "sample/input3.jpg", 1 );
    //system("rm square0.png");
    i= cvCloneImage(b.rot(i));
    cvSaveImage("rot.png",i);

    i= cvCloneImage(b.cut(i));
    cvSaveImage("cut.png",i);



    ip.breakimages();
    ip.convert2text();
    ip.getboard();

    cout<<"here is what we have in the board....\n\n";



    int x=0;
    for(int i=1;i<=3;++i)
    {
        for(int j=1;j<=3;++j)
        {
        ++x;
        cout<<board[x]<<" ";
	}

    cout<<endl;
    }

    cvReleaseImage(&i);
    //cvReleaseImage(&i2);
    return 0;
}



